import { GrignonSale } from '../types/production';

/**
 * Computes the Grignons sale total exclusively from Net Weight (KG) and Price per KG (TND/KG),
 * rounded to Tunisian millimes (3 decimal places).
 */
export function calculateGrignonTotalTnd(netWeightKg: number, unitPricePerKg: number): number {
  const safeKg = Math.max(0, Number(netWeightKg) || 0);
  const safePrice = Math.max(0, Number(unitPricePerKg) || 0);
  return Math.round(safeKg * safePrice * 1000) / 1000;
}

/**
 * Resolves the price per KG (TND/KG) for both new KG-priced records and historical TONNE-priced records.
 */
export function resolveGrignonPricePerKg(
  sale: Pick<
    Partial<GrignonSale>,
    'price_unit' | 'unit_price_tnd' | 'unit_price_per_tonne_tnd' | 'net_weight_kg' | 'total_price_tnd'
  >
): number {
  const unitPrice = Number(sale.unit_price_tnd || 0);
  const perTonne = Number(sale.unit_price_per_tonne_tnd || 0);
  const netKg = Number(sale.net_weight_kg || 0);
  const totalTnd = Number(sale.total_price_tnd || 0);

  if (sale.price_unit === 'KG') {
    if (unitPrice > 0) return unitPrice;
    if (netKg > 0 && totalTnd > 0) return Math.round((totalTnd / netKg) * 1000) / 1000;
    return 0;
  }

  // Legacy historical record stored as TONNE
  if (perTonne > 0) {
    return Math.round((perTonne / 1000) * 1000) / 1000;
  }
  if (unitPrice > 0) {
    return Math.round((unitPrice / 1000) * 1000) / 1000;
  }
  if (netKg > 0 && totalTnd > 0) {
    return Math.round((totalTnd / netKg) * 1000) / 1000;
  }
  return 0;
}

/**
 * Normalizes an optional vehicle plate string: returns trimmed uppercase plate or null when empty.
 */
export function normalizeOptionalPlate(plate?: string | null): string | null {
  const cleaned = (plate ?? '').trim().toUpperCase();
  return cleaned.length > 0 ? cleaned : null;
}
