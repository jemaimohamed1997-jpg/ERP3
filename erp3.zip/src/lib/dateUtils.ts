/**
 * Local-timezone date helpers for Huilerie Jemai ERP.
 * Avoids UTC midnight shifts caused by `new Date().toISOString().slice(0, 10)` in UTC+ timezones (e.g. Tunisia UTC+1).
 */

export function getLocalTodayIsoDate(date: Date = new Date()): string {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function normalizeIsoDate(value?: string | null, fallbackDate?: string): string {
  const fallback = fallbackDate || getLocalTodayIsoDate();
  if (!value) return fallback;
  const trimmed = String(value).trim();
  if (/^\d{4}-\d{2}-\d{2}/.test(trimmed)) {
    return trimmed.slice(0, 10);
  }
  const parsed = new Date(trimmed);
  if (Number.isNaN(parsed.getTime())) {
    return fallback;
  }
  return getLocalTodayIsoDate(parsed);
}

export function getYearFromIsoDate(value?: string | null): number {
  const iso = normalizeIsoDate(value);
  const year = Number(iso.slice(0, 4));
  return Number.isFinite(year) && year > 1900 ? year : new Date().getFullYear();
}
