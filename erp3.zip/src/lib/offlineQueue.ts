/**
 * Mode Hors-Ligne (F7): Snapshot cache + persistent mutation sync queue for Huilerie Jemai ERP.
 * Allows operators to continue creating receptions, grignon sales, purchases, clients, and expenses
 * when internet drops, print tickets immediately, and sync FIFO once online.
 */
import { Tank, Party, Operation, TankMovement, UserProfile, AppSettings } from '../types/stock';
import {
  OliveReception,
  ReceptionPayment,
  ProductionBatch,
  GrignonSale,
  PurchaseBatch,
  ExpenseItem,
  Employee,
  SalaryAdvance,
  SalaryPayment,
  AuditLog,
} from '../types/production';
import { calculateGrignonTotalTnd, normalizeOptionalPlate } from './grignonPricing';

export interface StorageLike {
  getItem(key: string): string | null;
  setItem(key: string, value: string): void;
  removeItem(key: string): void;
}

function getDefaultStorage(): StorageLike | null {
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      return window.localStorage;
    }
  } catch {
    // Storage disabled or SSR
  }
  return null;
}

const PROFILE_CACHE_KEY = 'huilerie_erp_cached_profile_v1';
const SNAPSHOT_CACHE_PREFIX = 'huilerie_erp_snapshot_v1_';
const QUEUE_STORAGE_KEY = 'huilerie_erp_offline_queue_v1';
const OFFLINE_SEQ_KEY = 'huilerie_erp_offline_seq_v1';

export interface OfflineErpSnapshot {
  cachedAt: string;
  tanks: Tank[];
  parties: Party[];
  operations: Operation[];
  movements: TankMovement[];
  appSettings: AppSettings;
  receptions: OliveReception[];
  receptionPayments: ReceptionPayment[];
  productionBatches: ProductionBatch[];
  grignonSales: GrignonSale[];
  purchases: PurchaseBatch[];
  expenses: ExpenseItem[];
  employees: Employee[];
  salaryAdvances: SalaryAdvance[];
  salaryPayments: SalaryPayment[];
  auditLogs: AuditLog[];
}

export type OfflineActionType =
  | 'CREATE_PARTY'
  | 'CREATE_OLIVE_RECEPTION'
  | 'CREATE_GRIGNON_SALE'
  | 'CREATE_PURCHASE'
  | 'CREATE_EXPENSE';

export type OfflineQueueStatus = 'PENDING' | 'SYNCING' | 'FAILED';

export interface OfflineQueueItem {
  id: string;
  type: OfflineActionType;
  payload: any;
  tempRecord: any;
  summary: string;
  operator: string;
  createdAt: string;
  status: OfflineQueueStatus;
  retryCount: number;
  lastError?: string | null;
}

export function isNetworkLikeError(err: unknown): boolean {
  if (typeof navigator !== 'undefined' && navigator.onLine === false) {
    return true;
  }
  const msg = String((err as any)?.message || err || '').toLowerCase();
  return (
    msg.includes('failed to fetch') ||
    msg.includes('networkerror') ||
    msg.includes('network request failed') ||
    msg.includes('load failed') ||
    msg.includes('internet_disconnected') ||
    msg.includes('fetch') ||
    msg.includes('timeout') ||
    msg.includes('econnrefused')
  );
}

// ----------------------------------------------------------------------------
// PROFILE & READ SNAPSHOT CACHE
// ----------------------------------------------------------------------------
export function saveCachedProfile(
  profile: UserProfile,
  storage: StorageLike | null = getDefaultStorage()
): void {
  if (!storage) return;
  try {
    storage.setItem(PROFILE_CACHE_KEY, JSON.stringify(profile));
  } catch {
    // Ignore storage quota errors
  }
}

export function loadCachedProfile(
  storage: StorageLike | null = getDefaultStorage()
): UserProfile | null {
  if (!storage) return null;
  try {
    const raw = storage.getItem(PROFILE_CACHE_KEY);
    return raw ? (JSON.parse(raw) as UserProfile) : null;
  } catch {
    return null;
  }
}

export function clearCachedProfile(
  storage: StorageLike | null = getDefaultStorage()
): void {
  if (!storage) return;
  try {
    storage.removeItem(PROFILE_CACHE_KEY);
  } catch {
    // Ignore
  }
}

export function saveOfflineSnapshot(
  profileId: string,
  snapshot: OfflineErpSnapshot,
  storage: StorageLike | null = getDefaultStorage()
): void {
  if (!storage || !profileId) return;
  try {
    storage.setItem(`${SNAPSHOT_CACHE_PREFIX}${profileId}`, JSON.stringify(snapshot));
  } catch {
    // Ignore storage quota errors
  }
}

export function loadOfflineSnapshot(
  profileId: string,
  storage: StorageLike | null = getDefaultStorage()
): OfflineErpSnapshot | null {
  if (!storage || !profileId) return null;
  try {
    const raw = storage.getItem(`${SNAPSHOT_CACHE_PREFIX}${profileId}`);
    return raw ? (JSON.parse(raw) as OfflineErpSnapshot) : null;
  } catch {
    return null;
  }
}

export function clearOfflineSnapshot(
  profileId: string,
  storage: StorageLike | null = getDefaultStorage()
): void {
  if (!storage || !profileId) return;
  try {
    storage.removeItem(`${SNAPSHOT_CACHE_PREFIX}${profileId}`);
  } catch {
    // Ignore
  }
}

// ----------------------------------------------------------------------------
// OFFLINE QUEUE PERSISTENCE
// ----------------------------------------------------------------------------
function nextOfflineSeq(storage: StorageLike | null): number {
  if (!storage) return Math.floor(Math.random() * 900) + 100;
  try {
    const current = Number(storage.getItem(OFFLINE_SEQ_KEY) || '0') || 0;
    const next = current + 1;
    storage.setItem(OFFLINE_SEQ_KEY, String(next));
    return next;
  } catch {
    return Math.floor(Math.random() * 900) + 100;
  }
}

export function getOfflineQueue(
  storage: StorageLike | null = getDefaultStorage()
): OfflineQueueItem[] {
  if (!storage) return [];
  try {
    const raw = storage.getItem(QUEUE_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? (parsed as OfflineQueueItem[]) : [];
  } catch {
    return [];
  }
}

function saveOfflineQueue(
  items: OfflineQueueItem[],
  storage: StorageLike | null = getDefaultStorage()
): void {
  if (!storage) return;
  try {
    storage.setItem(QUEUE_STORAGE_KEY, JSON.stringify(items));
  } catch {
    // Ignore quota error
  }
}

export function enqueueOfflineAction(
  params: {
    type: OfflineActionType;
    payload: any;
    tempRecord: any;
    summary: string;
    operator: string;
  },
  storage: StorageLike | null = getDefaultStorage()
): OfflineQueueItem {
  const queue = getOfflineQueue(storage);
  const item: OfflineQueueItem = {
    id: `off-q-${Date.now()}-${Math.floor(Math.random() * 10000)}`,
    type: params.type,
    payload: params.payload,
    tempRecord: params.tempRecord,
    summary: params.summary,
    operator: params.operator,
    createdAt: new Date().toISOString(),
    status: 'PENDING',
    retryCount: 0,
    lastError: null,
  };
  saveOfflineQueue([...queue, item], storage);
  return item;
}

export function removeOfflineQueueItem(
  itemId: string,
  storage: StorageLike | null = getDefaultStorage()
): OfflineQueueItem[] {
  const next = getOfflineQueue(storage).filter((q) => q.id !== itemId);
  saveOfflineQueue(next, storage);
  return next;
}

export function clearOfflineQueue(
  storage: StorageLike | null = getDefaultStorage()
): void {
  saveOfflineQueue([], storage);
}

// ----------------------------------------------------------------------------
// TEMP RECORD FACTORIES (IMMEDIATE PRINTABLE RECEIPTS WHILE OFFLINE)
// ----------------------------------------------------------------------------
export function buildTempParty(
  input: { name: string; phone?: string; notes?: string },
  storage: StorageLike | null = getDefaultStorage()
): Party {
  const seq = nextOfflineSeq(storage);
  const now = new Date().toISOString();
  const code = `OFF-CLI-${String(seq).padStart(3, '0')}`;
  return {
    id: `off-cli-${Date.now()}-${seq}`,
    code,
    name: input.name.trim(),
    phone: input.phone?.trim() || undefined,
    notes: input.notes?.trim() || undefined,
    is_active: true,
    is_deleted: false,
    created_at: now,
  };
}

export function buildTempOliveReception(
  input: Omit<OliveReception, 'id' | 'ticket_number' | 'created_at' | 'updated_at'>,
  storage: StorageLike | null = getDefaultStorage()
): OliveReception {
  const seq = nextOfflineSeq(storage);
  const now = new Date().toISOString();
  return {
    ...input,
    id: `off-olv-${Date.now()}-${seq}`,
    ticket_number: `OFF-OLV-${String(seq).padStart(4, '0')}`,
    created_at: now,
  };
}

export function buildTempGrignonSale(
  input: Omit<GrignonSale, 'id' | 'doc_number' | 'created_at' | 'updated_at'>,
  storage: StorageLike | null = getDefaultStorage()
): GrignonSale {
  const seq = nextOfflineSeq(storage);
  const now = new Date().toISOString();
  const netKg = Number(input.net_weight_kg || 0);
  const unitPriceKg = Number(input.unit_price_tnd || 0);
  return {
    ...input,
    id: `off-gri-${Date.now()}-${seq}`,
    doc_number: `OFF-GRI-${String(seq).padStart(4, '0')}`,
    truck_plate: normalizeOptionalPlate(input.truck_plate),
    driver_name: input.driver_name?.trim() || null,
    net_weight_kg: netKg,
    net_weight_tonnes: Math.round((netKg / 1000) * 1000) / 1000,
    price_unit: 'KG',
    unit_price_per_tonne_tnd: 0,
    unit_price_tnd: unitPriceKg,
    total_price_tnd: calculateGrignonTotalTnd(netKg, unitPriceKg),
    notes: input.notes?.trim() || null,
    created_at: now,
  };
}

export function buildTempPurchase(
  input: Omit<PurchaseBatch, 'id' | 'doc_number' | 'created_at' | 'updated_at'>,
  storage: StorageLike | null = getDefaultStorage()
): PurchaseBatch {
  const seq = nextOfflineSeq(storage);
  const now = new Date().toISOString();
  return {
    ...input,
    id: `off-ach-${Date.now()}-${seq}`,
    doc_number: `OFF-ACH-${String(seq).padStart(4, '0')}`,
    created_at: now,
  };
}

export function buildTempExpense(
  input: Omit<ExpenseItem, 'id' | 'created_at'>,
  storage: StorageLike | null = getDefaultStorage()
): ExpenseItem {
  const seq = nextOfflineSeq(storage);
  const now = new Date().toISOString();
  return {
    ...input,
    id: `off-exp-${Date.now()}-${seq}`,
    created_at: now,
  };
}

// ----------------------------------------------------------------------------
// FIFO SYNC ENGINE WITH MUTEX & TEMP-PARTY DEPENDENCY RESOLUTION
// ----------------------------------------------------------------------------
export interface OfflineSyncExecutors {
  createParty: (input: { name: string; phone?: string; notes?: string }) => Promise<Party>;
  createOliveReception: (
    input: Omit<OliveReception, 'id' | 'ticket_number' | 'created_at' | 'updated_at'>
  ) => Promise<OliveReception>;
  createGrignonSale: (
    input: Omit<GrignonSale, 'id' | 'doc_number' | 'created_at' | 'updated_at'>
  ) => Promise<GrignonSale>;
  createPurchase: (
    input: Omit<PurchaseBatch, 'id' | 'doc_number' | 'created_at' | 'updated_at'>
  ) => Promise<PurchaseBatch>;
  createExpense: (input: Omit<ExpenseItem, 'id' | 'created_at'>) => Promise<ExpenseItem>;
  appendAudit?: (params: {
    action: string;
    module: string;
    record_id?: string;
    details: string;
    userName?: string;
  }) => Promise<void>;
}

export interface OfflineSyncResult {
  syncedCount: number;
  failedCount: number;
  remainingCount: number;
  syncedItems: Array<{ queueId: string; type: OfflineActionType; createdRecord: any }>;
  failedItems: Array<{ queueId: string; error: string }>;
}

let activeSyncPromise: Promise<OfflineSyncResult> | null = null;

export async function processOfflineQueue(
  executors: OfflineSyncExecutors,
  options: {
    storage?: StorageLike | null;
    retryFailed?: boolean;
    targetId?: string;
    onQueueChange?: (queue: OfflineQueueItem[]) => void;
  } = {}
): Promise<OfflineSyncResult> {
  if (activeSyncPromise) {
    return activeSyncPromise;
  }

  const storage = options.storage !== undefined ? options.storage : getDefaultStorage();
  const retryFailed = options.retryFailed !== false;

  activeSyncPromise = (async () => {
    const initialQueue = getOfflineQueue(storage);
    if (initialQueue.length === 0) {
      return {
        syncedCount: 0,
        failedCount: 0,
        remainingCount: 0,
        syncedItems: [],
        failedItems: [],
      };
    }

    // Track offline temporary party IDs created earlier in this batch -> real Supabase Party
    const tempPartyMap: Record<string, Party> = {};
    const syncedIds = new Set<string>();
    const syncedItems: OfflineSyncResult['syncedItems'] = [];
    const failedItems: OfflineSyncResult['failedItems'] = [];

    let workingQueue = [...initialQueue];

    for (let i = 0; i < workingQueue.length; i++) {
      const item = workingQueue[i];
      if (options.targetId && item.id !== options.targetId) {
        continue;
      }
      if (item.status === 'FAILED' && !retryFailed && !options.targetId) {
        continue;
      }

      // Mark item SYNCING
      workingQueue = workingQueue.map((q) =>
        q.id === item.id ? { ...q, status: 'SYNCING' as const, lastError: null } : q
      );
      saveOfflineQueue(workingQueue, storage);
      options.onQueueChange?.(workingQueue);

      try {
        let createdRecord: any;
        let auditPayload: {
          action: string;
          module: string;
          record_id?: string;
          details: string;
          userName?: string;
        } | null = null;

        if (item.type === 'CREATE_PARTY') {
          createdRecord = await executors.createParty(item.payload);
          if (item.tempRecord?.id) {
            tempPartyMap[item.tempRecord.id] = createdRecord;
          }
          auditPayload = {
            action: 'CREATION_CLIENT_SYNC',
            module: 'CLIENTS',
            record_id: createdRecord.id,
            details: `Sync hors-ligne client ${createdRecord.code} - ${createdRecord.name}`,
            userName: item.operator,
          };
        } else if (item.type === 'CREATE_OLIVE_RECEPTION') {
          const payload = { ...item.payload };
          const mappedParty = payload.party_id ? tempPartyMap[payload.party_id] : undefined;
          if (mappedParty) {
            payload.party_id = mappedParty.id;
            payload.party_code = mappedParty.code;
            payload.party_name = mappedParty.name;
          }
          if (typeof payload.party_id === 'string' && payload.party_id.startsWith('off-cli-')) {
            throw new Error(
              'Le nouveau client associé hors-ligne doit être synchronisé avant cette réception.'
            );
          }
          createdRecord = await executors.createOliveReception(payload);
          auditPayload = {
            action: 'RECEPTION_OLIVES_SYNC',
            module: 'RECEPTIONS',
            record_id: createdRecord.id,
            details: `Sync hors-ligne ${item.tempRecord?.ticket_number || ''} → ${createdRecord.ticket_number} (${createdRecord.net_weight_kg} KG)`,
            userName: item.operator,
          };
        } else if (item.type === 'CREATE_GRIGNON_SALE') {
          createdRecord = await executors.createGrignonSale(item.payload);
          auditPayload = {
            action: 'VENTE_GRIGNONS_SYNC',
            module: 'GRIGNONS',
            record_id: createdRecord.id,
            details: `Sync hors-ligne ${item.tempRecord?.doc_number || ''} → ${createdRecord.doc_number} (${createdRecord.net_weight_kg} KG)`,
            userName: item.operator,
          };
        } else if (item.type === 'CREATE_PURCHASE') {
          createdRecord = await executors.createPurchase(item.payload);
          auditPayload = {
            action: 'ACHAT_DIRECT_SYNC',
            module: 'PURCHASES',
            record_id: createdRecord.id,
            details: `Sync hors-ligne ${item.tempRecord?.doc_number || ''} → ${createdRecord.doc_number}`,
            userName: item.operator,
          };
        } else if (item.type === 'CREATE_EXPENSE') {
          createdRecord = await executors.createExpense(item.payload);
          auditPayload = {
            action: 'DEPENSE_EXPLOITATION_SYNC',
            module: 'FINANCES',
            record_id: createdRecord.id,
            details: `Sync hors-ligne charge ${createdRecord.label} (${Number(createdRecord.amount_tnd).toFixed(3)} TND)`,
            userName: item.operator,
          };
        }

        // Best-effort audit log AFTER primary record commit so audit errors never trigger duplicate retries
        if (auditPayload && executors.appendAudit) {
          try {
            await executors.appendAudit(auditPayload);
          } catch {
            // Non-fatal audit logging failure
          }
        }

        syncedIds.add(item.id);
        syncedItems.push({ queueId: item.id, type: item.type, createdRecord });

        // Remove synced item immediately from storage so partial sync never duplicates
        workingQueue = workingQueue.filter((q) => q.id !== item.id);
        // Update any subsequent pending olive receptions referencing this temp party ID
        if (item.type === 'CREATE_PARTY' && item.tempRecord?.id && createdRecord?.id) {
          workingQueue = workingQueue.map((q) => {
            if (
              q.type === 'CREATE_OLIVE_RECEPTION' &&
              q.payload?.party_id === item.tempRecord.id
            ) {
              return {
                ...q,
                payload: {
                  ...q.payload,
                  party_id: createdRecord.id,
                  party_code: createdRecord.code,
                  party_name: createdRecord.name,
                },
                tempRecord: {
                  ...q.tempRecord,
                  party_id: createdRecord.id,
                  party_code: createdRecord.code,
                },
              };
            }
            return q;
          });
        }
        saveOfflineQueue(workingQueue, storage);
        options.onQueueChange?.(workingQueue);
        i--; // Adjust index since item was removed
      } catch (err: any) {
        const errorMessage = err?.message || 'Erreur de synchronisation';
        workingQueue = workingQueue.map((q) =>
          q.id === item.id
            ? {
                ...q,
                status: 'FAILED' as const,
                retryCount: (q.retryCount || 0) + 1,
                lastError: errorMessage,
              }
            : q
        );
        saveOfflineQueue(workingQueue, storage);
        options.onQueueChange?.(workingQueue);
        failedItems.push({ queueId: item.id, error: errorMessage });

        // If network dropped mid-sync, stop processing remaining items
        if (isNetworkLikeError(err)) {
          break;
        }
      }
    }

    const finalQueue = getOfflineQueue(storage);
    return {
      syncedCount: syncedItems.length,
      failedCount: failedItems.length,
      remainingCount: finalQueue.length,
      syncedItems,
      failedItems,
    };
  })().finally(() => {
    activeSyncPromise = null;
  });

  return activeSyncPromise;
}

/**
 * Merges temporary records from pending/failed queue items into state lists
 * so offline-created operations are immediately visible in tables and printable.
 */
export function mergeOptimisticQueueRecords<T extends { id: string }>(
  baseList: T[],
  queue: OfflineQueueItem[],
  actionType: OfflineActionType,
  prepend: boolean = true
): T[] {
  const tempRecords = queue
    .filter((q) => q.type === actionType && q.tempRecord)
    .map((q) => q.tempRecord as T);
  if (tempRecords.length === 0) return baseList;
  const existingIds = new Set(baseList.map((r) => r.id));
  const missing = tempRecords.filter((r) => !existingIds.has(r.id));
  if (missing.length === 0) return baseList;
  return prepend ? [...missing.reverse(), ...baseList] : [...baseList, ...missing];
}
