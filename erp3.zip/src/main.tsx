import { createRoot } from 'react-dom/client';
import { registerSW } from 'virtual:pwa-register';
import App from './App.tsx';
import './index.css';

if (typeof window !== 'undefined' && 'serviceWorker' in navigator) {
  registerSW({
    immediate: true,
    onRegisteredSW(_swUrl, registration) {
      if (!registration) return;
      setInterval(() => {
        if (navigator.onLine) {
          void registration.update().catch(() => {});
        }
      }, 30 * 60 * 1000);
    },
    onOfflineReady() {
      console.info('Huilerie Jemai ERP prêt pour le mode hors-ligne.');
    },
  });
}

createRoot(document.getElementById('root')!).render(<App />);
