import React, { useState } from 'react';
import { X, CheckCircle, Truck, Calendar, AlertCircle, RefreshCw } from 'lucide-react';
import { GrignonSale, GrignonPaymentMode } from '../../types/production';
import { translations, Language } from '../../lib/i18n';
import { calculateGrignonTotalTnd, normalizeOptionalPlate } from '../../lib/grignonPricing';

export type GrignonSaleCreateInput = Omit<
  GrignonSale,
  'id' | 'doc_number' | 'created_at' | 'updated_at'
>;

interface GrignonSaleModalProps {
  currentOperator: string;
  lang: Language;
  onClose: () => void;
  onSubmit: (sale: GrignonSaleCreateInput) => Promise<void>;
}

export const GrignonSaleModal: React.FC<GrignonSaleModalProps> = ({
  currentOperator,
  lang,
  onClose,
  onSubmit,
}) => {
  const t = translations[lang];
  const todayStr = new Date().toISOString().slice(0, 10);

  const [saleDate, setSaleDate] = useState<string>(todayStr);
  const [buyerName, setBuyerName] = useState<string>('');
  const [truckPlate, setTruckPlate] = useState<string>('');
  const [driverName, setDriverName] = useState<string>('');

  const [grossWeight, setGrossWeight] = useState<number>(24500);
  const [tareWeight, setTareWeight] = useState<number>(9500);
  const [unitPriceKg, setUnitPriceKg] = useState<number | ''>(0.18);
  const [paymentMode, setPaymentMode] = useState<GrignonPaymentMode>('ESPECES');
  const [paymentStatus, setPaymentStatus] = useState<'PAYE' | 'IMPAYE'>('PAYE');
  const [notes, setNotes] = useState<string>('');

  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Calculations strictly in KG & TND/KG
  const netWeightKg = Math.max(0, Number(grossWeight) - Number(tareWeight));
  const netWeightTonnes = Math.round((netWeightKg / 1000) * 1000) / 1000;
  const numericUnitPriceKg = unitPriceKg === '' ? 0 : Number(unitPriceKg);
  const totalPriceTnd = calculateGrignonTotalTnd(netWeightKg, numericUnitPriceKg);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (!buyerName.trim()) {
      setErrorMsg("Veuillez saisir le nom de l'acheteur ou de l'usine d'extraction.");
      return;
    }
    if (netWeightKg <= 0) {
      setErrorMsg('Le poids net de grignons doit être strictement supérieur à zéro.');
      return;
    }
    if (numericUnitPriceKg <= 0) {
      setErrorMsg('Le prix par kg doit être strictement supérieur à zéro.');
      return;
    }

    setIsSubmitting(true);
    try {
      await onSubmit({
        date: saleDate || todayStr,
        buyer_name: buyerName.trim(),
        truck_plate: normalizeOptionalPlate(truckPlate),
        driver_name: driverName.trim() || null,
        gross_weight_kg: Number(grossWeight),
        tare_weight_kg: Number(tareWeight),
        net_weight_kg: Number(netWeightKg),
        net_weight_tonnes: netWeightTonnes,
        price_unit: 'KG',
        unit_price_per_tonne_tnd: 0,
        unit_price_tnd: numericUnitPriceKg,
        total_price_tnd: Number(totalPriceTnd),
        payment_mode: paymentMode,
        payment_status: paymentStatus,
        operator: currentOperator,
        notes: notes.trim() || null,
      });
    } catch (err: any) {
      setErrorMsg(err?.message || 'Erreur lors de la création de la vente de grignons.');
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/55 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl max-w-xl w-full overflow-hidden flex flex-col max-h-[92vh] border border-stone-200">
        {/* Header */}
        <div className="px-6 py-4 bg-stone-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <Truck className="w-5 h-5 text-amber-400" />
            <div>
              <h2 className="font-bold text-base">
                Nouveau Bon de Vente des Grignons (فيتورة)
              </h2>
              <span className="text-[11px] text-stone-400">
                Vente directe · Tarification par kilogramme (TND / KG)
              </span>
            </div>
          </div>
          <button
            type="button"
            disabled={isSubmitting}
            onClick={onClose}
            className="p-1.5 hover:bg-stone-800 rounded-lg text-stone-400 hover:text-white cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-5">
          {errorMsg && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-800 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Date de vente */}
          <div className="p-3.5 bg-amber-50/60 rounded-xl border border-amber-200">
            <label className="block text-xs font-bold text-amber-950 mb-1 flex items-center gap-1.5">
              <Calendar className="w-4 h-4 text-amber-700" />
              <span>Date de la Vente *</span>
            </label>
            <input
              type="date"
              required
              value={saleDate}
              onChange={(e) => setSaleDate(e.target.value)}
              className="w-full p-2.5 bg-white border border-amber-300 rounded-lg text-xs font-mono font-bold text-stone-900 focus:outline-none focus:ring-2 focus:ring-amber-500"
            />
          </div>

          {/* Buyer & Optional Truck Plate */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">
                Acheteur / Usine d&apos;extraction *
              </label>
              <input
                type="text"
                required
                value={buyerName}
                onChange={(e) => setBuyerName(e.target.value)}
                placeholder="Ex: Usine d'Huile & Grignons..."
                className="w-full p-2.5 bg-stone-50 border border-stone-300 rounded-lg text-xs font-medium"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">
                Matricule Camion (optionnel)
              </label>
              <input
                type="text"
                value={truckPlate}
                onChange={(e) => setTruckPlate(e.target.value)}
                placeholder="Ex: 145 TU 8900 (facultatif)"
                className="w-full p-2.5 bg-stone-50 border border-stone-300 rounded-lg text-xs font-mono font-bold uppercase"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-stone-700 mb-1">
              Nom du Chauffeur (optionnel)
            </label>
            <input
              type="text"
              value={driverName}
              onChange={(e) => setDriverName(e.target.value)}
              placeholder="Ex: Habib Mansour"
              className="w-full p-2 bg-stone-50 border border-stone-300 rounded-lg text-xs"
            />
          </div>

          {/* Weighing Section */}
          <div className="p-4 bg-stone-50 rounded-xl border border-stone-200 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-stone-800">
              Pesée du Camion (Bascule Pont)
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-[11px] font-semibold text-stone-600 mb-1">
                  Poids Brut (KG) *
                </label>
                <input
                  type="number"
                  min="1"
                  step="1"
                  value={grossWeight}
                  onChange={(e) => setGrossWeight(Number(e.target.value))}
                  required
                  className="w-full p-2 bg-white border border-stone-300 rounded text-xs font-mono font-bold"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-stone-600 mb-1">
                  Tare (KG) *
                </label>
                <input
                  type="number"
                  min="0"
                  step="1"
                  value={tareWeight}
                  onChange={(e) => setTareWeight(Number(e.target.value))}
                  required
                  className="w-full p-2 bg-white border border-stone-300 rounded text-xs font-mono font-bold"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-amber-800 mb-1">
                  Poids Net de Grignons
                </label>
                <div className="p-2 bg-amber-50 border border-amber-300 rounded text-xs font-mono font-black text-amber-950 text-center">
                  {netWeightKg.toLocaleString()} KG
                </div>
              </div>
            </div>
          </div>

          {/* Pricing per KG & Payment */}
          <div className="p-4 bg-stone-50 rounded-xl border border-stone-200 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <label className="text-xs font-bold text-stone-800">
                Tarification &amp; Règlement
              </label>
              <span className="text-[11px] font-mono font-semibold text-amber-800 bg-amber-50 border border-amber-200 px-2 py-0.5 rounded">
                Unité : TND / KG
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">
                  Prix par kg (TND / KG) *
                </label>
                <input
                  type="number"
                  min="0.001"
                  step="0.001"
                  value={unitPriceKg}
                  onChange={(e) =>
                    setUnitPriceKg(e.target.value === '' ? '' : Number(e.target.value))
                  }
                  placeholder="Ex: 0.180"
                  required
                  className="w-full p-2 bg-white border border-stone-300 rounded text-xs font-mono font-bold"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">
                  Mode de Paiement
                </label>
                <select
                  value={paymentMode}
                  onChange={(e) => setPaymentMode(e.target.value as GrignonPaymentMode)}
                  className="w-full p-2 bg-white border border-stone-300 rounded text-xs font-medium"
                >
                  <option value="ESPECES">Espèces (نقدا)</option>
                  <option value="CHEQUE">Chèque (شيك)</option>
                  <option value="VIREMENT">Virement bancaire (تحويل)</option>
                  <option value="A_TERME">À terme / Crédit (مؤجل)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">
                  Statut Règlement
                </label>
                <select
                  value={paymentStatus}
                  onChange={(e) => setPaymentStatus(e.target.value as 'PAYE' | 'IMPAYE')}
                  className="w-full p-2 bg-white border border-stone-300 rounded text-xs font-medium"
                >
                  <option value="PAYE">Payé (خالص)</option>
                  <option value="IMPAYE">Non Payé / Crédit (غير خالص)</option>
                </select>
              </div>
            </div>
          </div>

          {/* Total Banner */}
          <div className="p-4 bg-amber-50 rounded-xl border border-amber-300 flex items-center justify-between">
            <div>
              <span className="text-xs font-bold text-amber-950 uppercase tracking-wide block">
                Montant Total de la Vente :
              </span>
              <span className="text-[11px] font-mono text-amber-800">
                {netWeightKg.toLocaleString()} KG × {numericUnitPriceKg.toFixed(3)} TND/kg
              </span>
            </div>
            <span className="font-mono text-xl font-black text-amber-950">
              {totalPriceTnd.toFixed(3)} TND
            </span>
          </div>

          <div>
            <label className="block text-xs font-semibold text-stone-700 mb-1">
              Remarques
            </label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Ex: Chargement du matin..."
              className="w-full p-2 bg-stone-50 border border-stone-300 rounded text-xs"
            />
          </div>

          {/* Submit */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-stone-200">
            <button
              type="button"
              disabled={isSubmitting}
              onClick={onClose}
              className="px-4 py-2 border border-stone-300 hover:bg-stone-100 text-stone-700 rounded-lg text-xs font-semibold cursor-pointer"
            >
              {t.cancel}
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-5 py-2.5 bg-amber-600 hover:bg-amber-700 disabled:bg-stone-400 text-white rounded-lg text-xs font-bold flex items-center gap-2 shadow-2xs cursor-pointer"
            >
              {isSubmitting ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Enregistrement...</span>
                </>
              ) : (
                <>
                  <CheckCircle className="w-4 h-4" />
                  <span>Valider &amp; Émettre le Bon de Vente</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
