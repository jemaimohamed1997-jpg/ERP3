import React, { useState } from 'react';
import {
  WifiOff,
  RefreshCw,
  Clock,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
  Trash2,
  RotateCcw,
} from 'lucide-react';
import { OfflineQueueItem } from '../lib/offlineQueue';

interface OfflineSyncBannerProps {
  browserOnline: boolean;
  queue: OfflineQueueItem[];
  isSyncing: boolean;
  cachedAt?: string | null;
  onSyncAll: () => void;
  onRetryItem: (itemId: string) => void;
  onRemoveItem: (itemId: string) => void;
}

const ACTION_LABELS: Record<string, string> = {
  CREATE_PARTY: 'Nouveau Client',
  CREATE_OLIVE_RECEPTION: 'Réception Olives',
  CREATE_GRIGNON_SALE: 'Vente Grignons',
  CREATE_PURCHASE: 'Achat Huilerie',
  CREATE_EXPENSE: 'Dépense Caisse',
};

export const OfflineSyncBanner: React.FC<OfflineSyncBannerProps> = ({
  browserOnline,
  queue,
  isSyncing,
  cachedAt,
  onSyncAll,
  onRetryItem,
  onRemoveItem,
}) => {
  const [expanded, setExpanded] = useState(false);

  const failedCount = queue.filter((q) => q.status === 'FAILED').length;
  const pendingCount = queue.length;

  // Hide completely when online and nothing in queue
  if (browserOnline && pendingCount === 0) {
    return null;
  }

  return (
    <div className="no-print mb-4 rounded-xl border overflow-hidden shadow-2xs bg-white border-amber-300">
      <div
        className={`px-4 py-2.5 flex flex-wrap items-center justify-between gap-2 text-xs ${
          !browserOnline
            ? 'bg-stone-900 text-amber-100'
            : failedCount > 0
            ? 'bg-rose-50 text-rose-950'
            : 'bg-amber-50 text-amber-950'
        }`}
      >
        <div className="flex items-center gap-2.5 min-w-0">
          {!browserOnline ? (
            <WifiOff className="w-4 h-4 text-amber-400 shrink-0" />
          ) : failedCount > 0 ? (
            <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
          ) : (
            <Clock className="w-4 h-4 text-amber-700 shrink-0" />
          )}

          <div className="min-w-0">
            <span className="font-bold block">
              {!browserOnline
                ? 'Mode Hors-Ligne actif — Consultation & saisie locale activées'
                : failedCount > 0
                ? `${failedCount} opération(s) hors-ligne en échec de synchronisation`
                : `${pendingCount} opération(s) hors-ligne en attente de synchronisation`}
            </span>
            <span className="text-[11px] opacity-80 block">
              {!browserOnline
                ? `Les nouveaux clients, réceptions, ventes grignons, achats et dépenses sont mis en file (${pendingCount} en attente)${
                    cachedAt
                      ? ` · Cache du ${new Date(cachedAt).toLocaleString('fr-TN')}`
                      : ''
                  }.`
                : 'Connexion rétablie : vous pouvez synchroniser la file vers Supabase.'}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          {browserOnline && pendingCount > 0 && (
            <button
              type="button"
              disabled={isSyncing}
              onClick={onSyncAll}
              className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-600 disabled:bg-stone-400 text-white rounded-lg text-[11px] font-bold flex items-center gap-1.5 cursor-pointer"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
              <span>{isSyncing ? 'Synchronisation...' : 'Synchroniser'}</span>
            </button>
          )}

          {pendingCount > 0 && (
            <button
              type="button"
              onClick={() => setExpanded((v) => !v)}
              className={`px-2.5 py-1.5 rounded-lg text-[11px] font-bold border flex items-center gap-1 cursor-pointer ${
                !browserOnline
                  ? 'bg-stone-800 border-stone-700 text-stone-200 hover:bg-stone-700'
                  : 'bg-white border-stone-300 text-stone-700 hover:bg-stone-100'
              }`}
            >
              <span>File ({pendingCount})</span>
              {expanded ? (
                <ChevronUp className="w-3.5 h-3.5" />
              ) : (
                <ChevronDown className="w-3.5 h-3.5" />
              )}
            </button>
          )}
        </div>
      </div>

      {expanded && pendingCount > 0 && (
        <div className="divide-y divide-stone-100 bg-white text-xs max-h-64 overflow-y-auto">
          {queue.map((item) => (
            <div
              key={item.id}
              className="px-4 py-2.5 flex flex-wrap items-center justify-between gap-2 hover:bg-stone-50"
            >
              <div className="min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="px-1.5 py-0.5 rounded bg-stone-100 border border-stone-200 font-mono text-[10px] font-bold text-stone-700">
                    {ACTION_LABELS[item.type] || item.type}
                  </span>
                  <span className="font-bold text-stone-900">{item.summary}</span>
                  <span
                    className={`px-1.5 py-0.5 rounded text-[10px] font-bold uppercase ${
                      item.status === 'FAILED'
                        ? 'bg-rose-100 text-rose-800'
                        : item.status === 'SYNCING'
                        ? 'bg-blue-100 text-blue-800'
                        : 'bg-amber-100 text-amber-800'
                    }`}
                  >
                    {item.status === 'FAILED'
                      ? 'Échec'
                      : item.status === 'SYNCING'
                      ? 'Envoi...'
                      : 'En attente'}
                  </span>
                </div>
                <span className="text-[10px] text-stone-500 font-mono block mt-0.5">
                  Saisi le {new Date(item.createdAt).toLocaleString('fr-TN')} par {item.operator}
                  {item.lastError ? ` · Erreur: ${item.lastError}` : ''}
                </span>
              </div>

              <div className="flex items-center gap-1.5 shrink-0">
                {browserOnline && item.status !== 'SYNCING' && (
                  <button
                    type="button"
                    disabled={isSyncing}
                    onClick={() => onRetryItem(item.id)}
                    className="px-2 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 rounded text-[10px] font-bold flex items-center gap-1 cursor-pointer"
                    title="Synchroniser cet élément"
                  >
                    <RotateCcw className="w-3 h-3" />
                    <span>Réessayer</span>
                  </button>
                )}
                <button
                  type="button"
                  disabled={item.status === 'SYNCING'}
                  onClick={() => onRemoveItem(item.id)}
                  className="p-1 hover:bg-rose-50 text-stone-400 hover:text-rose-700 border border-stone-200 rounded cursor-pointer"
                  title="Supprimer de la file locale"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
