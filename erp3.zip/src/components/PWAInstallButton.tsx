import React, { useState } from 'react';
import { Download, Smartphone, X } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

export const PWAInstallButton: React.FC = () => {
  const { canInstall, isIOS, promptInstall } = usePWAInstall();
  const [showIOSTip, setShowIOSTip] = useState(false);

  if (!canInstall && !isIOS) return null;

  return (
    <div className="relative">
      <button
        type="button"
        onClick={() => {
          if (canInstall) {
            void promptInstall();
          } else {
            setShowIOSTip((v) => !v);
          }
        }}
        className="px-2.5 py-1.5 bg-amber-500 hover:bg-amber-400 text-stone-950 rounded-lg text-xs font-extrabold flex items-center gap-1.5 transition cursor-pointer shadow-2xs"
        title="Installer l'application hors-ligne (PWA)"
      >
        {canInstall ? (
          <Download className="w-3.5 h-3.5" />
        ) : (
          <Smartphone className="w-3.5 h-3.5" />
        )}
        <span className="hidden sm:inline">Installer App</span>
      </button>

      {showIOSTip && isIOS && (
        <div className="absolute right-0 mt-2 w-64 bg-stone-900 text-stone-100 border border-stone-700 rounded-xl shadow-2xl p-3 text-[11px] z-50">
          <div className="flex items-start justify-between gap-2 mb-1">
            <span className="font-bold text-amber-300">Installation iOS / Safari</span>
            <button
              type="button"
              onClick={() => setShowIOSTip(false)}
              className="text-stone-400 hover:text-white cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
          <p className="text-stone-300 leading-relaxed">
            Appuyez sur le bouton <strong>Partager</strong> puis choisissez{' '}
            <strong>« Sur l&apos;écran d&apos;accueil »</strong> pour utiliser HuilerieERP hors-ligne.
          </p>
        </div>
      )}
    </div>
  );
};
