import assert from 'node:assert/strict';
import fs from 'node:fs';
import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import {
  calculateGrignonTotalTnd,
  normalizeOptionalPlate,
  resolveGrignonPricePerKg,
} from '../src/lib/grignonPricing';
import { PrintDocument } from '../src/components/Documents/PrintDocument';
import { GrignonSaleModal } from '../src/components/GrignonsModule/GrignonSaleModal';
import { DEFAULT_APP_SETTINGS } from '../src/lib/supabase';
import {
  StorageLike,
  saveOfflineSnapshot,
  loadOfflineSnapshot,
  clearOfflineSnapshot,
  enqueueOfflineAction,
  getOfflineQueue,
  clearOfflineQueue,
  buildTempParty,
  buildTempOliveReception,
  buildTempGrignonSale,
  buildTempPurchase,
  buildTempExpense,
  mergeOptimisticQueueRecords,
  processOfflineQueue,
} from '../src/lib/offlineQueue';
import { GrignonSale, PurchaseBatch, SalaryAdvance, OliveReception } from '../src/types/production';
import { Party } from '../src/types/stock';
import { calculateClientStocks } from '../src/lib/stockCalculation';
import { getLocalTodayIsoDate, normalizeIsoDate, getYearFromIsoDate } from '../src/lib/dateUtils';
import { OliveReceptionsList } from '../src/components/OlivesModule/OliveReceptionsList';
import { ClientsList } from '../src/components/ClientsModule/ClientsList';

class MemoryStorage implements StorageLike {
  private map = new Map<string, string>();
  getItem(key: string): string | null {
    return this.map.has(key) ? this.map.get(key)! : null;
  }
  setItem(key: string, value: string): void {
    this.map.set(key, value);
  }
  removeItem(key: string): void {
    this.map.delete(key);
  }
}

async function run() {
  console.log('=== VERIFICATION SUITE: GRIGNONS, 80MM THERMAL TICKETS & F7 OFFLINE PWA ===');

  // 1A + 1B: Grignons kg pricing + optional matricule
  assert.equal(calculateGrignonTotalTnd(15000, 0.18), 2700.0);
  assert.equal(calculateGrignonTotalTnd(8450, 0.215), 1816.75);
  assert.equal(normalizeOptionalPlate(''), null);
  assert.equal(normalizeOptionalPlate('   '), null);
  assert.equal(normalizeOptionalPlate(null), null);
  assert.equal(normalizeOptionalPlate(' 145 tu 8900 '), '145 TU 8900');

  // Historical TONNE record conversion while preserving stored total
  const legacySale: GrignonSale = {
    id: 'gri-legacy',
    doc_number: 'BON-GRI-2025-0010',
    date: '2025-11-12',
    buyer_name: 'Huilerie Ancienne',
    truck_plate: '100 TU 1234',
    gross_weight_kg: 20000,
    tare_weight_kg: 10000,
    net_weight_kg: 10000,
    net_weight_tonnes: 10,
    price_unit: 'TONNE',
    unit_price_per_tonne_tnd: 180,
    unit_price_tnd: 180,
    total_price_tnd: 1800,
    payment_mode: 'ESPECES',
    payment_status: 'PAYE',
    operator: 'Admin',
    created_at: '2025-11-12T10:00:00Z',
  };
  assert.equal(resolveGrignonPricePerKg(legacySale), 0.18);

  // Verify GrignonSaleModal contains no "Prix par tonne" and matricule input is NOT required
  const modalHtml = renderToStaticMarkup(
    React.createElement(GrignonSaleModal, {
      currentOperator: 'Mohamed',
      lang: 'fr',
      onClose: () => {},
      onSubmit: async () => {},
    })
  );
  assert.equal(/prix par tonne/i.test(modalHtml), false, 'Prix par tonne must not appear in modal');
  assert.equal(modalHtml.includes('Prix par kg (TND / KG)'), true);
  assert.equal(modalHtml.includes('Matricule Camion (optionnel)'), true);
  assert.equal(
    /Matricule Camion[^<]*<\/label>\s*<input[^>]*required/i.test(modalHtml),
    false,
    'Matricule input must not have required attribute'
  );
  console.log('✓ [1A/1B] Grignons KG pricing & optional matricule form checks passed.');

  // 1C: Grignon 80mm Ticket (with plate vs without plate, short vs long buyer names)
  const grignonWithPlate: GrignonSale = {
    id: 'gri-1',
    doc_number: 'BON-GRI-2026-0042',
    date: '2026-11-14',
    buyer_name: 'Société Tunisienne Extraction Huile de Grignons du Sahel SARL',
    truck_plate: '198 TU 4521',
    driver_name: 'Salah Ben Ali',
    gross_weight_kg: 24500,
    tare_weight_kg: 9500,
    net_weight_kg: 15000,
    net_weight_tonnes: 15,
    price_unit: 'KG',
    unit_price_per_tonne_tnd: 0,
    unit_price_tnd: 0.185,
    total_price_tnd: 2775.0,
    payment_mode: 'VIREMENT',
    payment_status: 'PAYE',
    operator: 'Admin Jemai',
    notes: 'Chargement matin',
    created_at: '2026-11-14T08:30:00Z',
  };

  const grignonWithoutPlate: GrignonSale = {
    id: 'gri-2',
    doc_number: 'BON-GRI-2026-0043',
    date: '2026-11-14',
    buyer_name: 'Ali',
    truck_plate: null,
    driver_name: null,
    gross_weight_kg: 12000,
    tare_weight_kg: 4000,
    net_weight_kg: 8000,
    net_weight_tonnes: 8,
    price_unit: 'KG',
    unit_price_per_tonne_tnd: 0,
    unit_price_tnd: 0.18,
    total_price_tnd: 1440.0,
    payment_mode: 'ESPECES',
    payment_status: 'IMPAYE',
    operator: 'Opérateur 1',
    created_at: '2026-11-14T09:15:00Z',
  };

  const grignonRp80WithPlate = renderToStaticMarkup(
    React.createElement(PrintDocument, {
      docType: 'GRIGNON_SALE',
      settings: DEFAULT_APP_SETTINGS,
      data: grignonWithPlate,
      initialFormat: 'RP80',
      onClose: () => {},
    })
  );
  assert.equal(grignonRp80WithPlate.includes('BON VENTE GRIGNONS'), true);
  assert.equal(grignonRp80WithPlate.includes('198 TU 4521'), true);
  assert.equal(grignonRp80WithPlate.includes('0.185 TND/kg'), true);
  assert.equal(grignonRp80WithPlate.includes('2775.000 TND'), true);
  assert.equal(/par tonne|tnd\/t\b/i.test(grignonRp80WithPlate), false);
  assert.equal(grignonRp80WithPlate.includes('size: 80mm auto'), true);

  const grignonRp80NoPlate = renderToStaticMarkup(
    React.createElement(PrintDocument, {
      docType: 'GRIGNON_SALE',
      settings: DEFAULT_APP_SETTINGS,
      data: grignonWithoutPlate,
      initialFormat: 'RP80',
      onClose: () => {},
    })
  );
  assert.equal(grignonRp80NoPlate.includes('Matricule :'), false, 'No fake matricule rendered');
  assert.equal(grignonRp80NoPlate.includes('1440.000 TND'), true);
  assert.equal(grignonRp80NoPlate.includes('0.180 TND/kg'), true);
  console.log('✓ [1C] Grignons 80mm thermal ticket checks (with/without plate, long/short names) passed.');

  // 2: Purchase Receipt (BON-ACH) 80mm Ticket
  const purchaseLong: PurchaseBatch = {
    id: 'ach-1',
    doc_number: 'BON-ACH-2026-0018',
    date: '2026-11-14',
    supplier_name: 'Coopérative Agricole El Baraka des Producteurs Oléicoles de Sfax',
    supplier_phone: '+216 99 123 456',
    item_type: 'OLIVES',
    quantity: 3250,
    unit_price_tnd: 2.35,
    total_price_tnd: 7637.5,
    payment_mode: 'CHEQUE',
    payment_status: 'PAYE',
    operator: 'Mohamed Jemai',
    notes: 'Qualité extra',
    created_at: '2026-11-14T10:00:00Z',
  };
  const purchaseRp80 = renderToStaticMarkup(
    React.createElement(PrintDocument, {
      docType: 'PURCHASE_RECEIPT',
      settings: DEFAULT_APP_SETTINGS,
      data: purchaseLong,
      initialFormat: 'RP80',
      onClose: () => {},
    })
  );
  assert.equal(purchaseRp80.includes("BON D&#x27;ACHAT HUILERIE"), true);
  assert.equal(purchaseRp80.includes('BON-ACH-2026-0018'), true);
  assert.equal(purchaseRp80.includes('2.350 TND/kg'), true);
  assert.equal(purchaseRp80.includes('7637.500 TND'), true);
  assert.equal(purchaseRp80.includes('size: 80mm auto'), true);
  console.log('✓ [2] Purchase Receipt (BON-ACH) 80mm thermal ticket checks passed.');

  // 3: Salary Advance (BON-ADV) 80mm Ticket
  const advanceLong: SalaryAdvance = {
    id: 'adv-1',
    doc_number: 'BON-ADV-2026-0007',
    employee_id: 'emp-1',
    employee_name: 'Abderrahman Ben Mohamed El Khelifi',
    amount_tnd: 250.5,
    advance_date: '2026-11-14',
    period_month: '2026-11',
    payment_mode: 'ESPECES',
    operator: 'Admin Jemai',
    notes: 'Avance quinzaine novembre',
    is_settled: false,
    created_at: '2026-11-14T11:20:00Z',
  };
  const advanceRp80 = renderToStaticMarkup(
    React.createElement(PrintDocument, {
      docType: 'SALARY_ADVANCE',
      settings: DEFAULT_APP_SETTINGS,
      data: advanceLong,
      initialFormat: 'RP80',
      onClose: () => {},
    })
  );
  assert.equal(advanceRp80.includes("BON D&#x27;AVANCE SALAIRE"), true);
  assert.equal(advanceRp80.includes('BON-ADV-2026-0007'), true);
  assert.equal(advanceRp80.includes('Abderrahman Ben Mohamed El Khelifi'), true);
  assert.equal(advanceRp80.includes('250.500 TND'), true);
  assert.equal(advanceRp80.includes('14/11/2026'), true);
  assert.equal(advanceRp80.includes('2026-11'), true);
  console.log('✓ [3] Salary Advance (BON-ADV) 80mm thermal ticket checks passed.');

  // Non-regression: existing OLIVE_RECEPTION RP80 & A4 still render properly
  const oliveRec: OliveReception = {
    id: 'olv-1',
    ticket_number: 'BON-OLV-2026-0101',
    date: '2026-11-14',
    party_id: 'cli-1',
    party_name: 'Salem Mansour',
    gross_weight_kg: 1500,
    tare_weight_kg: 500,
    net_weight_kg: 1000,
    milling_fee_per_kg: 0.2,
    total_milling_fee_tnd: 200,
    paid_amount_tnd: 50,
    remaining_amount_tnd: 150,
    payment_status: 'PARTIEL',
    status: 'RECU',
    operator: 'Admin',
    created_at: '2026-11-14T08:00:00Z',
  };
  const oliveRp80 = renderToStaticMarkup(
    React.createElement(PrintDocument, {
      docType: 'OLIVE_RECEPTION',
      settings: DEFAULT_APP_SETTINGS,
      data: oliveRec,
      initialFormat: 'RP80',
      onClose: () => {},
    })
  );
  assert.equal(oliveRp80.includes('TICKET RÉCEPTION OLIVES'), true);
  assert.equal(oliveRp80.includes('BON-OLV-2026-0101'), true);
  console.log('✓ Non-regression check for OLIVE_RECEPTION RP80 passed.');

  // F7: Offline Snapshot + Queue + Failed Retry + Temp-Party Resolution Sync
  const storage = new MemoryStorage();
  clearOfflineQueue(storage);

  saveOfflineSnapshot(
    'prof-1',
    {
      cachedAt: '2026-11-14T09:00:00Z',
      tanks: [],
      parties: [],
      operations: [],
      movements: [],
      appSettings: DEFAULT_APP_SETTINGS,
      receptions: [oliveRec],
      receptionPayments: [],
      productionBatches: [],
      grignonSales: [],
      purchases: [],
      expenses: [],
      employees: [],
      salaryAdvances: [],
      salaryPayments: [],
      auditLogs: [],
    },
    storage
  );
  const loadedSnap = loadOfflineSnapshot('prof-1', storage);
  assert.ok(loadedSnap);
  assert.equal(loadedSnap.receptions.length, 1);

  const tempParty = buildTempParty({ name: 'Hassen Offline', phone: '+216 55 111 222' }, storage);
  enqueueOfflineAction(
    {
      type: 'CREATE_PARTY',
      payload: { name: 'Hassen Offline', phone: '+216 55 111 222' },
      tempRecord: tempParty,
      summary: `${tempParty.code} - ${tempParty.name}`,
      operator: 'Opérateur 1',
    },
    storage
  );

  const tempRec = buildTempOliveReception(
    {
      date: '2026-11-14',
      party_id: tempParty.id,
      party_name: tempParty.name,
      party_code: tempParty.code,
      gross_weight_kg: 1200,
      tare_weight_kg: 200,
      net_weight_kg: 1000,
      milling_fee_per_kg: 0.2,
      total_milling_fee_tnd: 200,
      paid_amount_tnd: 0,
      remaining_amount_tnd: 200,
      payment_status: 'IMPAYE',
      status: 'RECU',
      operator: 'Opérateur 1',
    },
    storage
  );
  enqueueOfflineAction(
    {
      type: 'CREATE_OLIVE_RECEPTION',
      payload: { ...tempRec },
      tempRecord: tempRec,
      summary: `${tempRec.ticket_number} · ${tempRec.party_name}`,
      operator: 'Opérateur 1',
    },
    storage
  );

  const tempGrignon = buildTempGrignonSale(
    {
      date: '2026-11-14',
      buyer_name: 'Acheteur Offline Sans Matricule',
      truck_plate: '',
      gross_weight_kg: 14000,
      tare_weight_kg: 6000,
      net_weight_kg: 8000,
      net_weight_tonnes: 8,
      price_unit: 'KG',
      unit_price_per_tonne_tnd: 0,
      unit_price_tnd: 0.19,
      total_price_tnd: 1520,
      payment_mode: 'ESPECES',
      payment_status: 'PAYE',
      operator: 'Opérateur 1',
    },
    storage
  );
  assert.equal(tempGrignon.truck_plate, null);
  assert.equal(tempGrignon.total_price_tnd, 1520);
  enqueueOfflineAction(
    {
      type: 'CREATE_GRIGNON_SALE',
      payload: { ...tempGrignon },
      tempRecord: tempGrignon,
      summary: `${tempGrignon.doc_number}`,
      operator: 'Opérateur 1',
    },
    storage
  );

  const tempPurchase = buildTempPurchase(
    {
      date: '2026-11-14',
      supplier_name: 'Fournisseur Offline',
      item_type: 'OLIVES',
      quantity: 500,
      unit_price_tnd: 2.1,
      total_price_tnd: 1050,
      payment_mode: 'ESPECES',
      payment_status: 'PAYE',
      operator: 'Opérateur 1',
    },
    storage
  );
  enqueueOfflineAction(
    {
      type: 'CREATE_PURCHASE',
      payload: { ...tempPurchase },
      tempRecord: tempPurchase,
      summary: `${tempPurchase.doc_number}`,
      operator: 'Opérateur 1',
    },
    storage
  );

  const tempExpense = buildTempExpense(
    {
      date: '2026-11-14',
      category: 'TRANSPORT',
      label: 'Carburant tracteur',
      amount_tnd: 85.5,
      payment_mode: 'ESPECES',
      operator: 'Opérateur 1',
    },
    storage
  );
  enqueueOfflineAction(
    {
      type: 'CREATE_EXPENSE',
      payload: { ...tempExpense },
      tempRecord: tempExpense,
      summary: tempExpense.label,
      operator: 'Opérateur 1',
    },
    storage
  );

  const queueBefore = getOfflineQueue(storage);
  assert.equal(queueBefore.length, 5);
  const optimisticSales = mergeOptimisticQueueRecords([], queueBefore, 'CREATE_GRIGNON_SALE');
  assert.equal(optimisticSales.length, 1);

  // First sync attempt fails at item 3 (Grignon) with network error -> first 2 items removed, remaining 3 stay queued
  let grignonCallCount = 0;
  let capturedReceptionPartyId = '';
  const sync1 = await processOfflineQueue(
    {
      createParty: async (input) => ({
        id: 'cli-real-99',
        code: 'CLI-099',
        name: input.name,
        is_active: true,
        is_deleted: false,
        created_at: new Date().toISOString(),
      }),
      createOliveReception: async (input) => {
        capturedReceptionPartyId = input.party_id;
        return { ...input, id: 'olv-real-1', ticket_number: 'BON-OLV-2026-0999', created_at: new Date().toISOString() };
      },
      createGrignonSale: async (input) => {
        grignonCallCount++;
        if (grignonCallCount === 1) {
          throw new Error('Failed to fetch');
        }
        return { ...input, id: 'gri-real-1', doc_number: 'BON-GRI-2026-0999', created_at: new Date().toISOString() };
      },
      createPurchase: async (input) => ({ ...input, id: 'ach-real-1', doc_number: 'BON-ACH-2026-0999', created_at: new Date().toISOString() }),
      createExpense: async (input) => ({ ...input, id: 'exp-real-1', created_at: new Date().toISOString() }),
    },
    { storage }
  );

  assert.equal(capturedReceptionPartyId, 'cli-real-99', 'Temp party ID must resolve to real synced ID');
  assert.equal(sync1.syncedCount, 2);
  assert.equal(sync1.failedCount, 1);
  assert.equal(sync1.remainingCount, 3);
  assert.equal(getOfflineQueue(storage)[0].status, 'FAILED');

  // Second sync (retry) finishes remaining 3 items cleanly
  const sync2 = await processOfflineQueue(
    {
      createParty: async () => {
        throw new Error('Should not be called again');
      },
      createOliveReception: async () => {
        throw new Error('Should not be called again');
      },
      createGrignonSale: async (input) => ({ ...input, id: 'gri-real-1', doc_number: 'BON-GRI-2026-0999', created_at: new Date().toISOString() }),
      createPurchase: async (input) => ({ ...input, id: 'ach-real-1', doc_number: 'BON-ACH-2026-0999', created_at: new Date().toISOString() }),
      createExpense: async (input) => ({ ...input, id: 'exp-real-1', created_at: new Date().toISOString() }),
    },
    { storage, retryFailed: true }
  );

  assert.equal(sync2.syncedCount, 3);
  assert.equal(sync2.failedCount, 0);
  assert.equal(sync2.remainingCount, 0);
  assert.equal(getOfflineQueue(storage).length, 0);

  // Audit check: Audit log failure must NOT mark a committed primary record as FAILED (prevents duplicate inserts)
  const auditFailSale = buildTempGrignonSale(
    {
      date: '2026-11-14',
      buyer_name: 'Client Audit Test',
      truck_plate: null,
      gross_weight_kg: 5000,
      tare_weight_kg: 2000,
      net_weight_kg: 3000,
      net_weight_tonnes: 3,
      price_unit: 'KG',
      unit_price_per_tonne_tnd: 0,
      unit_price_tnd: 0.2,
      total_price_tnd: 600,
      payment_mode: 'ESPECES',
      payment_status: 'PAYE',
      operator: 'Opérateur 1',
    },
    storage
  );
  enqueueOfflineAction(
    {
      type: 'CREATE_GRIGNON_SALE',
      payload: { ...auditFailSale },
      tempRecord: auditFailSale,
      summary: auditFailSale.doc_number,
      operator: 'Opérateur 1',
    },
    storage
  );
  const syncAuditFail = await processOfflineQueue(
    {
      createParty: async () => {
        throw new Error('Unused');
      },
      createOliveReception: async () => {
        throw new Error('Unused');
      },
      createGrignonSale: async (input) => ({
        ...input,
        id: 'gri-real-audit',
        doc_number: 'BON-GRI-2026-1000',
        created_at: new Date().toISOString(),
      }),
      createPurchase: async () => {
        throw new Error('Unused');
      },
      createExpense: async () => {
        throw new Error('Unused');
      },
      appendAudit: async () => {
        throw new Error('Simulated audit log failure');
      },
    },
    { storage }
  );
  assert.equal(syncAuditFail.syncedCount, 1);
  assert.equal(syncAuditFail.failedCount, 0);
  assert.equal(getOfflineQueue(storage).length, 0);

  // Audit check: Unresolved off-cli-* party ID must fail BEFORE calling createOliveReception
  let receptionCalledWithTempId = false;
  const orphanRec = buildTempOliveReception(
    {
      date: '2026-11-14',
      party_id: 'off-cli-missing',
      party_name: 'Orphan Client',
      gross_weight_kg: 1000,
      tare_weight_kg: 100,
      net_weight_kg: 900,
      milling_fee_per_kg: 0.2,
      total_milling_fee_tnd: 180,
      paid_amount_tnd: 0,
      remaining_amount_tnd: 180,
      payment_status: 'IMPAYE',
      status: 'RECU',
      operator: 'Opérateur 1',
    },
    storage
  );
  enqueueOfflineAction(
    {
      type: 'CREATE_OLIVE_RECEPTION',
      payload: { ...orphanRec },
      tempRecord: orphanRec,
      summary: orphanRec.ticket_number,
      operator: 'Opérateur 1',
    },
    storage
  );
  const syncOrphan = await processOfflineQueue(
    {
      createParty: async () => {
        throw new Error('Unused');
      },
      createOliveReception: async () => {
        receptionCalledWithTempId = true;
        throw new Error('Should never reach Supabase');
      },
      createGrignonSale: async () => {
        throw new Error('Unused');
      },
      createPurchase: async () => {
        throw new Error('Unused');
      },
      createExpense: async () => {
        throw new Error('Unused');
      },
    },
    { storage }
  );
  assert.equal(receptionCalledWithTempId, false);
  assert.equal(syncOrphan.failedCount, 1);
  clearOfflineQueue(storage);

  // Audit check: clearOfflineSnapshot clears user cache on logout
  clearOfflineSnapshot('user-1', storage);
  assert.equal(loadOfflineSnapshot('user-1', storage), null);

  console.log('✓ [F7] Offline snapshot cache, FIFO queue, temp-party dependency resolution, & retry sync passed.');

  // Verify migration 005 SQL file exists
  const mig005 = fs.readFileSync('supabase/migrations/005_grignon_optional_plate.sql', 'utf8');
  assert.equal(mig005.includes('ALTER COLUMN truck_plate DROP NOT NULL'), true);
  console.log('✓ Migration 005 verified.');

  // 4: Clients & Reception Notes immediate display & reload persistence fixes
  // 4A: Local date helpers avoid UTC midnight shift
  const localMorning = new Date(2026, 10, 14, 0, 15, 0); // 00:15 local time
  assert.equal(getLocalTodayIsoDate(localMorning), '2026-11-14');
  assert.equal(normalizeIsoDate('2026-11-14T23:50:00Z'), '2026-11-14');
  assert.equal(getYearFromIsoDate('2026-11-14'), 2026);

  // 4B: Newly created 0L client appears at top of 0L group & renders in ClientsList
  const oldParty: Party = {
    id: 'cli-old',
    code: 'CLI-001',
    name: 'Zied Ancien',
    is_active: true,
    is_deleted: false,
    created_at: '2026-10-01T10:00:00Z',
  };
  const brandNewParty: Party = {
    id: 'cli-new',
    code: 'CLI-099',
    name: 'Amira Nouveau',
    phone: '+216 98 765 432',
    is_active: true,
    is_deleted: false,
    created_at: '2026-11-14T23:45:00Z',
  };
  const clientSummaries = calculateClientStocks([oldParty, brandNewParty], [], [], []);
  assert.equal(clientSummaries.length, 2);
  assert.equal(clientSummaries[0].party.id, 'cli-new', 'Newly created client must sort first among 0L clients');
  const clientsHtml = renderToStaticMarkup(
    React.createElement(ClientsList, {
      clients: clientSummaries,
      canCreate: true,
      canEdit: true,
      canExport: true,
      lang: 'fr',
      onNewClient: async () => {},
      onPrintClientStatement: () => {},
      onExportExcel: () => {},
    })
  );
  assert.equal(clientsHtml.includes('CLI-099'), true);
  assert.equal(clientsHtml.includes('Amira Nouveau'), true);

  // 4C: OliveReceptionsList defaults to ALL so historical, backdated, and today's receptions all show immediately
  const pastRec: OliveReception = {
    ...oliveRec,
    id: 'olv-past',
    ticket_number: 'BON-OLV-2026-0005',
    date: '2026-10-12',
    party_name: 'Hedi Passé',
  };
  const futureOrCustomRec: OliveReception = {
    ...oliveRec,
    id: 'olv-custom',
    ticket_number: 'BON-OLV-2026-0102',
    date: getLocalTodayIsoDate(),
    party_name: 'Nadia AujourdHui',
  };
  const receptionsHtml = renderToStaticMarkup(
    React.createElement(OliveReceptionsList, {
      receptions: [futureOrCustomRec, pastRec],
      parties: [oldParty, brandNewParty],
      currentOperator: 'Admin',
      lang: 'fr',
      canCreate: true,
      canEdit: true,
      canPay: true,
      canExport: true,
      onNewReception: () => {},
      onEditReception: async () => {},
      onSendToQueue: () => {},
      onPrintA4: () => {},
      onPrintRP80: () => {},
      onConfirmPayment: async () => {},
      onExportExcel: () => {},
    })
  );
  assert.equal(receptionsHtml.includes('BON-OLV-2026-0005'), true, 'Past reception must be visible by default');
  assert.equal(receptionsHtml.includes('BON-OLV-2026-0102'), true, 'New reception must be visible by default');
  assert.equal(receptionsHtml.includes('Hedi Passé'), true);
  assert.equal(receptionsHtml.includes('Nadia AujourdHui'), true);

  // 4D: Verify server.ts Vite 8 WebSocket fix remains intact
  const serverTs = fs.readFileSync('server.ts', 'utf8');
  assert.equal(serverTs.includes('ws: { server: httpServer }'), true, 'Vite WebSocket fix in server.ts must stay intact');

  // 4E: Verify OliveReceptionModal & OliveReceptionsList no longer use UTC .toISOString().slice(0, 10)
  const modalSrc = fs.readFileSync('src/components/OlivesModule/OliveReceptionModal.tsx', 'utf8');
  const listSrc = fs.readFileSync('src/components/OlivesModule/OliveReceptionsList.tsx', 'utf8');
  assert.equal(modalSrc.includes('toISOString().slice(0, 10)'), false);
  assert.equal(listSrc.includes('toISOString().slice(0, 10)'), false);

  console.log('✓ [4] Clients & Olive Receptions display, local dates, sorting, and server.ts WebSocket checks passed.');

  console.log('=== ALL VERIFICATION CHECKS PASSED ===');
}

run().catch((err) => {
  console.error('❌ Verification failed:', err);
  process.exit(1);
});
