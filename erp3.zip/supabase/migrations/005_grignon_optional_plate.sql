-- ============================================================================
-- HUILERIE JEMAI ERP - MIGRATION 005: Grignons Optional Truck Plate & KG Default
-- Preserves all historical records while allowing empty/NULL truck_plate
-- and defaulting new sales to KG pricing.
-- ============================================================================

ALTER TABLE public.grignon_sales
  ALTER COLUMN truck_plate DROP NOT NULL;

ALTER TABLE public.grignon_sales
  ALTER COLUMN price_unit SET DEFAULT 'KG';

ALTER TABLE public.grignon_sales
  ALTER COLUMN unit_price_per_tonne_tnd SET DEFAULT 0;

COMMENT ON COLUMN public.grignon_sales.truck_plate IS 'Matricule camion optionnel (NULL autorisé)';
